# ExplainIt AI 🎓

**An educational AI assistant that helps students understand homework through step-by-step explanations, not just answers.**

Built for Averix Hacks | February 2026

---

## 📋 Hackathon Submission Details

**Name and School**: Idris Ibrahim - FUDMA  
**Date**: February 7, 2026  
**Project Name**: ExplainIt AI  

**Project Description**:  
ExplainIt AI is a web-based educational tool designed to help middle-school and high-school students truly understand their homework instead of memorizing answers. Many students rely on quick solutions without learning the reasoning behind them, which leads to gaps in understanding and poor academic confidence.

ExplainIt AI addresses this problem by generating clear, step-by-step explanations for homework questions using artificial intelligence. Students enter a question, select their grade level, and receive a structured breakdown that explains what to do, why each step matters, and how the solution is reached. The system intentionally avoids answer-only responses and focuses on teaching the problem-solving process.

Built with HTML, CSS, JavaScript, PHP, MySQL, and Gemini AI, the platform demonstrates how AI can be used responsibly as a learning assistant rather than a shortcut tool. ExplainIt AI promotes deeper comprehension, independent thinking, and better learning outcomes, making education more accessible and effective for students.

---

## 🎯 Problem Statement

Students often struggle with homework and turn to the internet for quick answers. However, getting just the final answer doesn't help them learn. They need to understand **how** to solve problems and **why** each step matters.

**ExplainIt AI** bridges this gap by acting as a patient tutor that breaks down complex problems into understandable steps, tailored to the student's grade level.

---

## 💡 Solution

ExplainIt AI is a web application that:

✅ Accepts homework questions from students  
✅ Identifies the student's grade level (Middle School or High School)  
✅ Uses Google Gemini AI to generate educational, step-by-step explanations  
✅ Focuses on teaching the **process**, not just providing answers  
✅ Logs all interactions for continuous improvement  

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | HTML5, CSS3, Vanilla JavaScript |
| **Backend** | PHP 8.x |
| **Database** | MySQL 8.x |
| **AI Model** | Google Gemini Pro API |
| **Server** | Apache (XAMPP) |

---

## 🚀 Features

### Core Features
- **Smart Question Processing**: Accepts text-based homework questions
- **Grade-Level Adaptation**: Tailors explanations for Middle School (6-8) or High School (9-12)
- **Step-by-Step Explanations**: AI breaks down solutions into logical, educational steps
- **Educational Focus**: Designed to teach understanding, not provide shortcuts
- **Clean UI**: Modern, responsive interface inspired by Google's design language

### Technical Features
- **RESTful API**: Clean PHP backend with JSON responses
- **Database Logging**: Tracks all questions and explanations for analytics
- **Error Handling**: Graceful error messages and retry mechanisms
- **Security**: Input validation, prepared statements, and XSS protection
- **Performance Tracking**: Logs API response times for optimization

---

## 📁 Project Structure

```
ExplainIt/
├── api/
│   └── explain.php          # Main API endpoint
├── css/
│   └── style.css            # Stylesheet with Google-inspired design
├── database/
│   └── schema.sql           # MySQL database schema
├── js/
│   └── app.js               # Frontend logic and API communication
├── config.php               # Configuration (DB + API keys)
├── index.html               # Main application interface
└── README.md                # This file
```

---

## ⚙️ Setup Instructions

### Prerequisites
- XAMPP (or similar LAMP/WAMP stack)
- Google Gemini API Key ([Get one here](https://makersuite.google.com/app/apikey))
- Modern web browser

### Installation Steps

1. **Clone or download** this project to your XAMPP `htdocs` directory:
   ```
   C:\xampp\htdocs\ExplainIt\
   ```

2. **Create the database**:
   - Open phpMyAdmin (http://localhost/phpmyadmin)
   - Import `database/schema.sql` or run the SQL commands manually

3. **Configure the application**:
   - Open `config.php`
   - Add your Gemini API key:
     ```php
     define('GEMINI_API_KEY', 'YOUR_ACTUAL_API_KEY_HERE');
     ```
   - Update database credentials if needed (default: root with no password)

4. **Start Apache and MySQL** in XAMPP Control Panel

5. **Access the application**:
   ```
   http://localhost/ExplainIt
   ```

---

## 🎮 Usage

1. **Enter your question** in the textarea (e.g., "What is photosynthesis?")
2. **Select your grade level** (Middle School or High School)
3. Click **"Explain This!"**
4. Read the **step-by-step explanation** generated by AI
5. Click **"Ask Another Question"** to continue learning

---

## 🧠 AI Prompt Engineering

The core of ExplainIt AI is its educational prompt design. The system instructs Gemini to:

- **Never give just the final answer**
- **Break solutions into logical steps**
- **Explain WHY each step matters**
- **Use age-appropriate language**
- **Encourage understanding over memorization**

Example prompt structure:
```
You are an expert educational tutor helping [grade level] understand how to solve problems.

CRITICAL RULES:
1. DO NOT just give the final answer
2. Break down the solution into clear, logical steps
3. Explain WHY each step is important
...
```

See `api/explain.php` → `buildEducationalPrompt()` for full implementation.

---

## 📊 Database Schema

### `explainit_logs` Table
Stores all student questions and AI explanations:

| Column | Type | Description |
|--------|------|-------------|
| `id` | INT | Auto-increment primary key |
| `question` | TEXT | Student's question |
| `grade_level` | ENUM | middle_school or high_school |
| `explanation` | TEXT | AI-generated explanation |
| `created_at` | TIMESTAMP | When the question was asked |

### `api_metrics` Table
Tracks API performance:

| Column | Type | Description |
|--------|------|-------------|
| `id` | INT | Auto-increment primary key |
| `response_time_ms` | INT | API response time in milliseconds |
| `success` | BOOLEAN | Whether the request succeeded |
| `error_message` | TEXT | Error details if failed |
| `created_at` | TIMESTAMP | When the request was made |

---

## 🔒 Security Considerations

- ✅ **Prepared Statements**: All database queries use PDO with prepared statements
- ✅ **Input Validation**: Server-side validation of all user inputs
- ✅ **XSS Protection**: HTML escaping on frontend rendering
- ✅ **API Key Protection**: Credentials stored in config file (add to .gitignore)
- ✅ **Error Handling**: Generic error messages to users, detailed logs for debugging

---

## 🎯 Future Enhancements

- 📸 **Image Upload**: Allow students to upload photos of handwritten problems
- 🌍 **Multi-Language Support**: Explanations in multiple languages
- 📚 **Subject Categorization**: Automatic detection of subject (Math, Science, etc.)
- 👤 **User Accounts**: Track individual student progress
- 📈 **Analytics Dashboard**: Visualize common questions and topics
- 🔊 **Text-to-Speech**: Audio explanations for accessibility

---

## 🏆 Why This Project Matters

**Educational Impact**: Helps students develop critical thinking and problem-solving skills instead of just copying answers.

**Accessibility**: Free, web-based tool available to any student with internet access.

**Scalability**: Lightweight architecture can handle thousands of concurrent users.

**Real-World Application**: Addresses a genuine pain point in modern education.

---

## 👨‍💻 Developer

**Built solo for Averix Hacks by Idris Ibrahim**  
**School**: Federal University Dutsin-Ma (FUDMA)

**Contact**: subpay001@gmail.com  
**GitHub**: [DevFuel01](https://github.com/DevFuel01?tab=repositories)  
**LinkedIn**: [devfuel01](https://www.linkedin.com/in/devfuel01/)

---

## 📄 License

This project is open-source and available under the MIT License.

---

## 🙏 Acknowledgments

- **Google Gemini AI** for powering the educational explanations
- **Google Design** for color palette inspiration
- **Inter Font** by Rasmus Andersson
- **[Averix Hacks]** for the opportunity to build this project

---

**Built with ❤️ for students everywhere.**