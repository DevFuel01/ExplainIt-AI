# ExplainIt AI - Quick Start Guide

**Get your hackathon project running in 10 minutes!**

---

## ✅ Prerequisites Checklist

Before you begin, make sure you have:

- [ ] **XAMPP** installed ([Download here](https://www.apachefriends.org/))
- [ ] **Google Gemini API Key** ([Get free key here](https://makersuite.google.com/app/apikey))
- [ ] **Modern web browser** (Chrome, Firefox, Edge, Safari)
- [ ] **Text editor** (VS Code, Sublime, Notepad++, etc.)

---

## 🚀 Setup Steps

### Step 1: Verify XAMPP Installation

1. Open **XAMPP Control Panel**
2. Click **Start** next to **Apache**
3. Click **Start** next to **MySQL**
4. Both should show green "Running" status

**Troubleshooting**:
- If Apache won't start, check if port 80 is in use (Skype, IIS, etc.)
- If MySQL won't start, check if port 3306 is in use

---

### Step 2: Set Up the Database

**Option A: Using phpMyAdmin (Recommended)**

1. Open browser and go to: `http://localhost/phpmyadmin`
2. Click **"New"** in the left sidebar
3. Database name: `explainit_db`
4. Collation: `utf8mb4_unicode_ci`
5. Click **"Create"**
6. Click **"Import"** tab
7. Choose file: `C:\xampp\htdocs\ExplainIt\database\schema.sql`
8. Click **"Go"**
9. You should see: "Import has been successfully finished"

**Option B: Using MySQL Command Line**

```bash
# Open XAMPP Shell or Command Prompt
cd C:\xampp\mysql\bin

# Login to MySQL
mysql -u root -p
# (Press Enter when asked for password - default is empty)

# Create database
CREATE DATABASE explainit_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Use the database
USE explainit_db;

# Import schema
SOURCE C:/xampp/htdocs/ExplainIt/database/schema.sql;

# Verify tables were created
SHOW TABLES;
# You should see: explainit_logs, api_metrics

# Exit
EXIT;
```

---

### Step 3: Configure Your API Key

1. Open `C:\xampp\htdocs\ExplainIt\config.php` in your text editor

2. Find this line:
   ```php
   define('GEMINI_API_KEY', 'YOUR_GEMINI_API_KEY_HERE');
   ```

3. Replace `YOUR_GEMINI_API_KEY_HERE` with your actual API key:
   ```php
   define('GEMINI_API_KEY', 'AIzaSyD...');  // Your real key
   ```

4. **Save the file**

**Getting Your API Key**:
1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Copy the key (starts with `AIzaSy...`)

---

### Step 4: Test the Application

1. Open your browser
2. Go to: `http://localhost/ExplainIt`
3. You should see the ExplainIt AI interface

**If you see a blank page or error**:
- Check Apache is running in XAMPP
- Check the URL is correct (case-sensitive on some systems)
- Check browser console for JavaScript errors (F12)

---

### Step 5: Submit a Test Question

1. In the question box, type:
   ```
   If a train travels 120 miles in 2 hours, what is its average speed?
   ```

2. Select **"Middle School (Grades 6-8)"**

3. Click **"Explain This!"**

4. Wait 2-4 seconds (you'll see a loading spinner)

5. You should see a detailed, step-by-step explanation!

**Expected Response**:
- Should NOT just say "60 mph"
- Should explain the concept of average speed
- Should show the formula (distance ÷ time)
- Should walk through the calculation
- Should be written in student-friendly language

---

## 🧪 Verification Checklist

After setup, verify everything works:

- [ ] Application loads at `http://localhost/ExplainIt`
- [ ] Can submit a question and get an explanation
- [ ] Explanation is educational (not just an answer)
- [ ] Middle School vs High School gives different complexity
- [ ] Database logs the question (check phpMyAdmin → explainit_logs)
- [ ] Error handling works (try submitting empty question)
- [ ] Responsive design works (resize browser window)

---

## 🐛 Common Issues & Solutions

### Issue: "Failed to generate explanation"

**Possible Causes**:
1. **Invalid API Key**
   - Solution: Double-check your API key in `config.php`
   - Verify it starts with `AIzaSy`
   - Make sure there are no extra spaces

2. **API Key Not Configured**
   - Solution: You still have `YOUR_GEMINI_API_KEY_HERE` in config.php
   - Replace with your actual key

3. **Network Issue**
   - Solution: Check your internet connection
   - Try accessing `https://generativelanguage.googleapis.com` in browser

4. **API Quota Exceeded**
   - Solution: Check your API usage in Google AI Studio
   - Free tier has limits (60 requests/minute)

---

### Issue: "Database connection failed"

**Possible Causes**:
1. **MySQL Not Running**
   - Solution: Start MySQL in XAMPP Control Panel

2. **Wrong Database Credentials**
   - Solution: Verify `config.php` has correct credentials:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_NAME', 'explainit_db');
     define('DB_USER', 'root');
     define('DB_PASS', '');  // Empty for default XAMPP
     ```

3. **Database Doesn't Exist**
   - Solution: Create `explainit_db` in phpMyAdmin
   - Import `schema.sql`

---

### Issue: Blank page or "500 Internal Server Error"

**Possible Causes**:
1. **PHP Syntax Error**
   - Solution: Check Apache error logs
   - Location: `C:\xampp\apache\logs\error.log`

2. **Missing Files**
   - Solution: Verify all files are in correct locations:
     ```
     ExplainIt/
     ├── api/explain.php
     ├── css/style.css
     ├── js/app.js
     ├── config.php
     └── index.html
     ```

3. **File Permissions** (rare on Windows)
   - Solution: Ensure files are readable

---

### Issue: "Method not allowed" error

**Cause**: Trying to access `api/explain.php` directly in browser

**Solution**: This endpoint only accepts POST requests. Use the main interface at `http://localhost/ExplainIt`

---

### Issue: Explanation looks like plain text (no formatting)

**Cause**: JavaScript not loading or error in `app.js`

**Solution**:
1. Open browser console (F12 → Console tab)
2. Look for JavaScript errors
3. Verify `js/app.js` exists and is accessible
4. Hard refresh the page (Ctrl+Shift+R)

---

## 📊 Verify Database Logging

To confirm questions are being logged:

1. Go to `http://localhost/phpmyadmin`
2. Click **"explainit_db"** in left sidebar
3. Click **"explainit_logs"** table
4. Click **"Browse"** tab
5. You should see your test questions listed

**What to check**:
- `question` column has your question text
- `grade_level` shows `middle_school` or `high_school`
- `explanation` has the AI response
- `created_at` shows current timestamp

---

## 🎨 Customization (Optional)

### Change Color Scheme

Edit `css/style.css` and modify CSS variables:

```css
:root {
    --primary-blue: #4285F4;  /* Change to your color */
    --primary-red: #EA4335;
    --primary-yellow: #FBBC04;
    --primary-green: #34A853;
}
```

### Change App Name

1. Edit `index.html`:
   ```html
   <h1>ExplainIt AI</h1>  <!-- Change this -->
   <title>ExplainIt AI - Learn How to Solve Problems</title>  <!-- And this -->
   ```

2. Edit `config.php`:
   ```php
   define('APP_NAME', 'ExplainIt AI');  // Change this
   ```

---

## 🚀 Ready for Demo!

Once everything works:

1. **Prepare 3-5 sample questions** covering different subjects:
   - Math problem
   - Science concept
   - Reading comprehension
   - History question

2. **Test both grade levels** to show adaptation

3. **Practice your pitch** using `JUDGE_SCRIPT.md`

4. **Take screenshots** for your presentation

5. **Note response times** to discuss performance

---

## 📞 Need Help?

If you're stuck:

1. **Check error logs**:
   - Apache: `C:\xampp\apache\logs\error.log`
   - PHP: `C:\xampp\php\logs\php_error_log`

2. **Enable debug mode**:
   - In `config.php`, set `ENVIRONMENT` to `'development'`
   - Refresh the page and check for detailed errors

3. **Test components individually**:
   - Database: Can you access phpMyAdmin?
   - Apache: Does `http://localhost` work?
   - PHP: Create a test file with `<?php phpinfo(); ?>`

---

## ✅ Final Checklist

Before the hackathon demo:

- [ ] Application runs without errors
- [ ] API key is configured and working
- [ ] Database is logging questions
- [ ] Tested on multiple browsers
- [ ] Tested on mobile (responsive design)
- [ ] Prepared sample questions
- [ ] Read `JUDGE_SCRIPT.md`
- [ ] Practiced 3-minute demo
- [ ] Screenshots ready for presentation

---

**You're all set! Good luck with your hackathon! 🎉**
