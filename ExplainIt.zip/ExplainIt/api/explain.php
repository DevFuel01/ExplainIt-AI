<?php

/**
 * ExplainIt AI - Main API Endpoint
 * Handles student questions and returns AI-generated educational explanations
 */

require_once '../config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed. Use POST.']);
    exit;
}

// Get and validate input
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['question']) || empty(trim($input['question']))) {
    http_response_code(400);
    echo json_encode(['error' => 'Question is required.']);
    exit;
}

if (!isset($input['grade_level']) || !in_array($input['grade_level'], ['middle_school', 'high_school'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Valid grade level is required (middle_school or high_school).']);
    exit;
}

$question = trim($input['question']);
$grade_level = $input['grade_level'];

// Build educational prompt for Gemini
$prompt = buildEducationalPrompt($question, $grade_level);

// Call Gemini API
$start_time = microtime(true);
$gemini_response = callGeminiAPI($prompt);
$response_time = round((microtime(true) - $start_time) * 1000); // milliseconds

if ($gemini_response['success']) {
    $explanation = $gemini_response['explanation'];

    // Log to database
    logToDatabase($question, $grade_level, $explanation, $response_time, true);

    // Return success response
    echo json_encode([
        'success' => true,
        'explanation' => $explanation,
        'grade_level' => $grade_level
    ]);
} else {
    // Log error to database
    logToDatabase($question, $grade_level, '', $response_time, false, $gemini_response['error']);

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to generate explanation. Please try again.'
    ]);
}

function buildEducationalPrompt($question, $grade_level)
{
    $grade_context = ($grade_level === 'middle_school')
        ? 'a middle school student (grades 6-8)'
        : 'a high school student (grades 9-12)';

    $prompt = <<<PROMPT
You are an educational tutor helping {$grade_context}. Provide CONCISE, STRUCTURED explanations.

FORMATTING RULES:
- Use PLAIN TEXT only (no LaTeX, no *, no \$, no \\, no special symbols)
- Keep explanations CONCISE and CLEAR
- Use this exact structure:

STRUCTURE:
1. Brief intro (1 sentence: what we're solving)
2. Steps (numbered, with "Why:" for each)
3. Final Answer
4. Quick Check (verify the answer works)

EXAMPLE FORMAT:
"Let's solve: [restate question]

Step 1: [action]
Why: [brief reason]

Step 2: [action]
Why: [brief reason]

Final Answer: [result]

Quick Check: [verify it works]"

CRITICAL:
- Be CONCISE, not verbose
- Each "Why" should be 1-2 sentences max
- No long textbook explanations
- Plain text only
- Finish completely

QUESTION: {$question}

Provide a clear, concise explanation:
PROMPT;

    return $prompt;
}

/**
 * Call Google Gemini API
 */
function callGeminiAPI($prompt)
{
    $api_key = GEMINI_API_KEY;

    if ($api_key === 'YOUR_GEMINI_API_KEY_HERE') {
        return [
            'success' => false,
            'error' => 'API key not configured. Please add your Gemini API key to config.php'
        ];
    }

    $url = GEMINI_API_ENDPOINT . '?key=' . $api_key;

    $data = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $prompt]
                ]
            ]
        ],
        'generationConfig' => [
            'temperature' => 0.7,
            'topK' => 40,
            'topP' => 0.95,
            'maxOutputTokens' => 1536,
        ],
        'safetySettings' => [
            [
                'category' => 'HARM_CATEGORY_HARASSMENT',
                'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'
            ],
            [
                'category' => 'HARM_CATEGORY_HATE_SPEECH',
                'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'
            ],
            [
                'category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
                'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'
            ],
            [
                'category' => 'HARM_CATEGORY_DANGEROUS_CONTENT',
                'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'
            ]
        ]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        return [
            'success' => false,
            'error' => 'Network error: ' . $curl_error
        ];
    }

    if ($http_code !== 200) {
        return [
            'success' => false,
            'error' => 'API error (HTTP ' . $http_code . ')'
        ];
    }

    $result = json_decode($response, true);

    if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
        return [
            'success' => true,
            'explanation' => $result['candidates'][0]['content']['parts'][0]['text']
        ];
    }

    return [
        'success' => false,
        'error' => 'Unexpected API response format'
    ];
}

/**
 * Log question and explanation to database
 */
function logToDatabase($question, $grade_level, $explanation, $response_time, $success, $error = null)
{
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );

        // Log the question and explanation
        if ($success) {
            $stmt = $pdo->prepare('INSERT INTO explainit_logs (question, grade_level, explanation) VALUES (?, ?, ?)');
            $stmt->execute([$question, $grade_level, $explanation]);
        }

        // Log API metrics
        $stmt = $pdo->prepare('INSERT INTO api_metrics (response_time_ms, success, error_message) VALUES (?, ?, ?)');
        $stmt->execute([$response_time, $success ? 1 : 0, $error]);
    } catch (PDOException $e) {
        // Log error but don't expose to user
        error_log('Database error: ' . $e->getMessage());
    }
}
