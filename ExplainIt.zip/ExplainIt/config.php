<?php

/**
 * ExplainIt AI - Configuration File
 * Contains database credentials and API keys
 * 
 * IMPORTANT: Add this file to .gitignore to protect sensitive credentials
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'explainit_db');
define('DB_USER', 'root');  // Change for production
define('DB_PASS', '');      // Change for production

// Google Gemini API Configuration
// Get your API key from: https://makersuite.google.com/app/apikey
define('GEMINI_API_KEY', '');
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

// Application Settings
define('APP_NAME', 'ExplainIt AI');
define('APP_VERSION', '1.0.0');
define('ENVIRONMENT', 'development'); // development or production

// Error Reporting (disable in production)
if (ENVIRONMENT === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// CORS Headers (adjust for production)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');
