-- ExplainIt AI Database Schema
-- Creates the database and logging table for storing student questions and AI explanations

CREATE DATABASE IF NOT EXISTS explainit_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE explainit_db;

-- Table to log all questions and explanations
CREATE TABLE IF NOT EXISTS explainit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    grade_level ENUM('middle_school', 'high_school') NOT NULL,
    explanation TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created_at (created_at),
    INDEX idx_grade_level (grade_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional: Table for tracking API usage and performance
CREATE TABLE IF NOT EXISTS api_metrics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    response_time_ms INT,
    success BOOLEAN DEFAULT TRUE,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
