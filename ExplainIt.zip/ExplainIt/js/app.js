/**
 * ExplainIt AI - Frontend JavaScript
 * Handles form submission, API communication, and UI updates
 */

// DOM Elements
const explainForm = document.getElementById('explainForm');
const questionInput = document.getElementById('question');
const gradeLevelSelect = document.getElementById('gradeLevel');
const submitBtn = document.getElementById('submitBtn');
const btnText = submitBtn.querySelector('.btn-text');
const btnLoader = submitBtn.querySelector('.btn-loader');
const charCount = document.getElementById('charCount');

const responseSection = document.getElementById('responseSection');
const responseContent = document.getElementById('responseContent');
const newQuestionBtn = document.getElementById('newQuestionBtn');

const errorSection = document.getElementById('errorSection');
const errorMessage = document.getElementById('errorMessage');
const retryBtn = document.getElementById('retryBtn');

// API Configuration
const API_ENDPOINT = 'api/explain.php';

// Character counter
questionInput.addEventListener('input', () => {
    charCount.textContent = questionInput.value.length;
});

// Form submission
explainForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const question = questionInput.value.trim();
    const gradeLevel = gradeLevelSelect.value;
    
    // Validation
    if (!question) {
        showError('Please enter a question.');
        return;
    }
    
    if (!gradeLevel) {
        showError('Please select your grade level.');
        return;
    }
    
    // Show loading state
    setLoadingState(true);
    hideError();
    hideResponse();
    
    try {
        // Call API
        const response = await fetch(API_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                question: question,
                grade_level: gradeLevel
            })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            // Show explanation
            showResponse(data.explanation);
        } else {
            // Show error
            showError(data.error || 'Failed to generate explanation. Please try again.');
        }
        
    } catch (error) {
        console.error('Error:', error);
        showError('Network error. Please check your connection and try again.');
    } finally {
        setLoadingState(false);
    }
});

// New question button
newQuestionBtn.addEventListener('click', () => {
    hideResponse();
    hideError();
    questionInput.focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Retry button
retryBtn.addEventListener('click', () => {
    hideError();
    explainForm.dispatchEvent(new Event('submit'));
});

/**
 * Set loading state
 */
function setLoadingState(isLoading) {
    submitBtn.disabled = isLoading;
    
    if (isLoading) {
        btnText.style.display = 'none';
        btnLoader.style.display = 'flex';
    } else {
        btnText.style.display = 'inline';
        btnLoader.style.display = 'none';
    }
}

/**
 * Show response section
 */
function showResponse(explanation) {
    // Format the explanation with markdown-like rendering
    const formattedExplanation = formatExplanation(explanation);
    responseContent.innerHTML = formattedExplanation;
    
    responseSection.style.display = 'block';
    
    // Scroll to response
    setTimeout(() => {
        responseSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
}

/**
 * Hide response section
 */
function hideResponse() {
    responseSection.style.display = 'none';
}

/**
 * Show error section
 */
function showError(message) {
    errorMessage.textContent = message;
    errorSection.style.display = 'block';
    
    // Scroll to error
    setTimeout(() => {
        errorSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
}

/**
 * Hide error section
 */
function hideError() {
    errorSection.style.display = 'none';
}

/**
 * Format explanation text with basic markdown-like rendering
 */
function formatExplanation(text) {
    // Escape HTML
    text = escapeHtml(text);
    
    // Convert **bold** to <strong>
    text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    
    // Convert *italic* to <em>
    text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');
    
    // Convert numbered lists
    text = text.replace(/^(\d+)\.\s+(.+)$/gm, '<li>$2</li>');
    
    // Wrap consecutive <li> in <ol>
    text = text.replace(/(<li>.*<\/li>\n?)+/g, (match) => {
        return '<ol>' + match + '</ol>';
    });
    
    // Convert headings (### Heading)
    text = text.replace(/^###\s+(.+)$/gm, '<h4>$1</h4>');
    
    // Convert paragraphs (double newlines)
    text = text.split('\n\n').map(para => {
        // Don't wrap if already wrapped in tags
        if (para.trim().startsWith('<')) {
            return para;
        }
        return '<p>' + para.replace(/\n/g, '<br>') + '</p>';
    }).join('\n');
    
    return text;
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Auto-resize textarea
 */
questionInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = (this.scrollHeight) + 'px';
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    questionInput.focus();
});
